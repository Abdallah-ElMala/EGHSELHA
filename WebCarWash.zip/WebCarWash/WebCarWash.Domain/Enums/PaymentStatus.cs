﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebCarWash.Domain.Enums
{
    public enum PaymentStatus
    {
        PENDING = 1,
        SUCCESS = 2,
        FAILED = 3,
        REFUNDED = 4
    }
}
